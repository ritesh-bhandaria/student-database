PROJECT SUBMISSION;
BY RAGHAV PATIDAR
	RAKSHIT GOEL
	RITESH BHANDARIA

THIS FOLLOWING ZIP FILE CONTAINS:
1.A ZIP FOLDER FOR THE CODE OF THE FINAL PROJECT AS 
FinalDraft(2).zip
2. The final database used during the demonstration (it was downloaded before and might have a lot of conflicting entries as were testing the database and filling the tables manually)
pgdb(2).sql
3.THE FINAL PPT FILE FOR THE PROJECT
final ppt dbms.pptx
4.A pdf file for the report of the project named as 
DBMS Report.pdf

according to our knowledge these were the required files to be submitted and in case any file is missing please mail us we will upload it as well

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
